
  # Restaurant Ordering System

  This is a code bundle for Restaurant Ordering System. The original project is available at https://www.figma.com/design/kmTwMKIjv1QdDCyKlu6iYt/Restaurant-Ordering-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  